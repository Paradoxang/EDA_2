//FirstApp.jsx
import './App.css'
 
const FirstApp = () => {
    return (
        <>
            <h1> Counter </h1>
            <span> 10 </span>
        </>
    )
}
export default FirstApp
//

