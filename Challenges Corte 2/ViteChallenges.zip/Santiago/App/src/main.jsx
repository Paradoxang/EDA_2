//MAIN
import React from 'react'
import ReactDOM from 'react-dom/client'
//import App from './App'//
//import FirstApp from './FirstApp'
import './index.css'
import { GiftExpertApp } from './GiftExpertApp'

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
   <GiftExpertApp/>
  </React.StrictMode>
) 
//